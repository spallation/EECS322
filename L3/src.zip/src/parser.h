#pragma once

#include <L3.h>

namespace L3{
  Program L3_parse_file (char *fileName);
  // Function* L2_parse_file (char *fileName);
}
